package com.example.calculadoraimc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CalculoIMCActivity extends AppCompatActivity {

    EditText edtPeso, edtAltura;
    Button btnCalcular, btnLimpar, btnFechar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_imc);

        edtPeso = findViewById(R.id.edtPeso);
        edtAltura = findViewById(R.id.edtAltura);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnFechar = findViewById(R.id.btnFechar);

        btnCalcular.setOnClickListener(v -> {
            String pesoStr = edtPeso.getText().toString();
            String alturaStr = edtAltura.getText().toString();

            if (pesoStr.isEmpty() || alturaStr.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            double peso = Double.parseDouble(pesoStr);
            double altura = Double.parseDouble(alturaStr);
            double imc = peso / (altura * altura);

            String classificacao;

            if (imc < 18.5) {
                classificacao = "abaixo";
            } else if (imc < 25) {
                classificacao = "normal";
            } else if (imc < 30) {
                classificacao = "sobrepeso";
            } else if (imc < 35) {
                classificacao = "obesidade1";
            } else if (imc < 40) {
                classificacao = "obesidade2";
            } else {
                classificacao = "obesidade3";
            }

            Intent intent;
            switch (classificacao) {
                case "abaixo":
                    intent = new Intent(this, AbaixoDoPesoActivity.class);
                    break;
                case "normal":
                    intent = new Intent(this, PesoNormalActivity.class);
                    break;
                case "sobrepeso":
                    intent = new Intent(this, SobrepesoActivity.class);
                    break;
                case "obesidade1":
                    intent = new Intent(this, Obesidade1Activity.class);
                    break;
                case "obesidade2":
                    intent = new Intent(this, Obesidade2Activity.class);
                    break;
                default:
                    intent = new Intent(this, Obesidade3Activity.class);
                    break;
            }

            intent.putExtra("peso", peso);
            intent.putExtra("altura", altura);
            intent.putExtra("imc", imc);
            startActivity(intent);
        });

        btnLimpar.setOnClickListener(v -> {
            edtPeso.setText("");
            edtAltura.setText("");
        });

        btnFechar.setOnClickListener(v -> {
            finish(); // volta para a MainActivity
        });
    }
}
