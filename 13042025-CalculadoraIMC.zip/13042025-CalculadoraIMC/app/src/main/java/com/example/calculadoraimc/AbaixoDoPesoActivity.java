package com.example.calculadoraimc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AbaixoDoPesoActivity extends AppCompatActivity {

    TextView txtResultado;
    Button btnFechar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abaixo_do_peso);

        txtResultado = findViewById(R.id.txtResultado);
        btnFechar = findViewById(R.id.btnFechar);

        // Pegando os dados da tela anterior
        Intent intent = getIntent();
        double peso = intent.getDoubleExtra("peso", 0);
        double altura = intent.getDoubleExtra("altura", 0);
        double imc = intent.getDoubleExtra("imc", 0);

        // Montando o texto
        String resultado = "Peso: " + peso + " kg\n";
        resultado += "Altura: " + altura + " m\n";
        resultado += "IMC: " + imc + "\n";
        resultado += "Classificação: Abaixo do peso";

        txtResultado.setText(resultado);

        // Fechar a tela e voltar para a principal
        btnFechar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent voltar = new Intent(AbaixoDoPesoActivity.this, MainActivity.class);
                voltar.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(voltar);
                finish();
            }
        });
    }
}
